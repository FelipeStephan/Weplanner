/**
 * LOOPERA DESIGN SYSTEM — Tailwind CSS Preset
 * Digital Finance · v1.0.0
 *
 * Usage in tailwind.config.js:
 *   const loopera = require('./design-system/tailwind.preset')
 *   module.exports = { presets: [loopera], ... }
 *
 * Or in tailwind.config.ts:
 *   import loopera from './design-system/tailwind.preset'
 *   export default { presets: [loopera], ... }
 */

/** @type {import('tailwindcss').Config} */
const loopera = {
  theme: {
    extend: {
      // -----------------------------------------------------------------------
      // FONT FAMILY
      // -----------------------------------------------------------------------
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        mono: ['SF Mono', 'Fira Code', 'Cascadia Code', 'Consolas', 'monospace'],
      },

      // -----------------------------------------------------------------------
      // COLORS
      // -----------------------------------------------------------------------
      colors: {
        // Brand palette
        brand: {
          50:  '#E5EFFF',
          100: '#CCDEFF',
          200: '#99BCFF',
          300: '#66A0FF',
          400: '#3380FF',
          500: '#0057FF',
          600: '#0047D4',
          700: '#0038A9',
          800: '#002880',
          900: '#001A57',
          950: '#000D2E',
          DEFAULT: '#0057FF',
        },
        // Semantic tokens — mapped to CSS variables for theme switching
        bg: {
          base:         'var(--bg-base)',
          subtle:       'var(--bg-subtle)',
          surface:      'var(--bg-surface)',
          elevated:     'var(--bg-elevated)',
          brand:        'var(--bg-brand)',
          'brand-subtle': 'var(--bg-brand-subtle)',
        },
        text: {
          primary:   'var(--text-primary)',
          secondary: 'var(--text-secondary)',
          tertiary:  'var(--text-tertiary)',
          disabled:  'var(--text-disabled)',
          inverse:   'var(--text-inverse)',
          brand:     'var(--text-brand)',
          success:   'var(--text-success)',
          warning:   'var(--text-warning)',
          error:     'var(--text-error)',
        },
        border: {
          subtle:  'var(--border-subtle)',
          default: 'var(--border-default)',
          strong:  'var(--border-strong)',
          brand:   'var(--border-brand)',
          success: 'var(--border-success)',
          warning: 'var(--border-warning)',
          error:   'var(--border-error)',
        },
        // Status (direct hex for component classes)
        success: {
          50:  '#ECFDF5',
          100: '#D1FAE5',
          500: '#10B981',
          600: '#059669',
          700: '#047857',
          DEFAULT: '#10B981',
        },
        warning: {
          50:  '#FFFBEB',
          100: '#FEF3C7',
          500: '#F59E0B',
          600: '#D97706',
          700: '#B45309',
          DEFAULT: '#F59E0B',
        },
        error: {
          50:  '#FEF2F2',
          100: '#FEE2E2',
          500: '#EF4444',
          600: '#DC2626',
          700: '#B91C1C',
          DEFAULT: '#EF4444',
        },
        info: {
          50:  '#EFF6FF',
          100: '#DBEAFE',
          500: '#3B82F6',
          600: '#2563EB',
          700: '#1D4ED8',
          DEFAULT: '#3B82F6',
        },
      },

      // -----------------------------------------------------------------------
      // BORDER RADIUS
      // -----------------------------------------------------------------------
      borderRadius: {
        none:  '0px',
        xs:    '2px',
        sm:    '4px',
        md:    '6px',
        lg:    '8px',
        xl:    '12px',
        '2xl': '16px',
        '3xl': '24px',
        full:  '9999px',
      },

      // -----------------------------------------------------------------------
      // BOX SHADOW
      // -----------------------------------------------------------------------
      boxShadow: {
        xs:     '0px 1px 2px rgba(15, 23, 42, 0.06)',
        sm:     '0px 1px 3px rgba(15, 23, 42, 0.1), 0px 1px 2px rgba(15, 23, 42, 0.06)',
        md:     '0px 4px 6px rgba(15, 23, 42, 0.07), 0px 2px 4px rgba(15, 23, 42, 0.06)',
        lg:     '0px 10px 15px rgba(15, 23, 42, 0.08), 0px 4px 6px rgba(15, 23, 42, 0.05)',
        xl:     '0px 20px 25px rgba(15, 23, 42, 0.1), 0px 8px 10px rgba(15, 23, 42, 0.05)',
        '2xl':  '0px 25px 50px rgba(15, 23, 42, 0.18)',
        inner:  'inset 0px 2px 4px rgba(15, 23, 42, 0.06)',
        brand:  '0px 4px 16px rgba(0, 87, 255, 0.24)',
        none:   'none',
      },

      // -----------------------------------------------------------------------
      // TYPOGRAPHY
      // -----------------------------------------------------------------------
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '1rem' }],       // 10px
        xs:    ['0.75rem',  { lineHeight: '1rem' }],        // 12px
        sm:    ['0.875rem', { lineHeight: '1.25rem' }],     // 14px
        base:  ['1rem',     { lineHeight: '1.5rem' }],      // 16px
        lg:    ['1.125rem', { lineHeight: '1.75rem' }],     // 18px
        xl:    ['1.25rem',  { lineHeight: '1.75rem' }],     // 20px
        '2xl': ['1.5rem',   { lineHeight: '2rem' }],        // 24px
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],     // 30px
        '4xl': ['2.25rem',  { lineHeight: '2.5rem' }],      // 36px
        '5xl': ['3rem',     { lineHeight: '1.1' }],         // 48px
        '6xl': ['3.75rem',  { lineHeight: '1.1' }],         // 60px
      },

      fontWeight: {
        light:     '300',
        normal:    '400',
        medium:    '500',
        semibold:  '600',
        bold:      '700',
        extrabold: '800',
        black:     '900',
      },

      lineHeight: {
        none:    '1',
        tight:   '1.1',
        snug:    '1.25',
        normal:  '1.45',
        relaxed: '1.625',
        loose:   '2',
      },

      letterSpacing: {
        tighter: '-0.05em',
        tight:   '-0.025em',
        normal:   '0em',
        wide:     '0.025em',
        wider:    '0.05em',
        widest:   '0.1em',
      },

      // -----------------------------------------------------------------------
      // SPACING (extends default Tailwind scale)
      // -----------------------------------------------------------------------
      spacing: {
        '0.5': '2px',
        '1':   '4px',
        '1.5': '6px',
        '2':   '8px',
        '2.5': '10px',
        '3':   '12px',
        '4':   '16px',
        '5':   '20px',
        '6':   '24px',
        '7':   '28px',
        '8':   '32px',
        '9':   '36px',
        '10':  '40px',
        '12':  '48px',
        '14':  '56px',
        '16':  '64px',
        '20':  '80px',
        '24':  '96px',
        '32':  '128px',
      },

      // -----------------------------------------------------------------------
      // TRANSITIONS
      // -----------------------------------------------------------------------
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
        out: 'cubic-bezier(0, 0, 0.2, 1)',
        in: 'cubic-bezier(0.4, 0, 1, 1)',
      },

      transitionDuration: {
        75:  '75ms',
        100: '100ms',
        150: '150ms',
        200: '200ms',
        300: '300ms',
        500: '500ms',
      },

      // -----------------------------------------------------------------------
      // Z-INDEX
      // -----------------------------------------------------------------------
      zIndex: {
        base:     '0',
        raised:   '10',
        dropdown: '100',
        sticky:   '200',
        overlay:  '300',
        modal:    '400',
        toast:    '500',
        tooltip:  '600',
      },
    },
  },
  plugins: [],
}

module.exports = loopera
